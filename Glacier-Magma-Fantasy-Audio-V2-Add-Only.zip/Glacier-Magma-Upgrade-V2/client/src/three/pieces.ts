import * as THREE from 'three';
import { makeMarbleTextures } from './textures.js';

const V = (pts) => pts.map(([r, y]) => new THREE.Vector2(r, y));
const BASE = [[0, 0], [0.37, 0], [0.38, 0.05], [0.36, 0.1], [0.28, 0.15]];
const lathe = (pts, seg) => new THREE.LatheGeometry(V(pts), seg);

function knightHead() {
  const sh = new THREE.Shape();
  [[-0.24, 0.12], [-0.3, 0.6], [-0.24, 1.0], [-0.1, 1.24], [-0.02, 1.36], [0.06, 1.26], [0.34, 0.98], [0.46, 0.84], [0.43, 0.72], [0.27, 0.73], [0.14, 0.64], [0.22, 0.4], [0.3, 0.12]]
    .forEach(([x, y], i) => (i ? sh.lineTo(x, y) : sh.moveTo(x, y)));
  const g = new THREE.ExtrudeGeometry(sh, { depth: 0.26, bevelEnabled: true, bevelThickness: 0.07, bevelSize: 0.05, bevelSegments: 2 });
  g.translate(-0.04, 0, -0.13);
  return g;
}

/** Returns [{geo, pos:[x,y,z], rot:[x,y,z]?, isHead?}] describing a piece; ice = faceted (low segment) lathes. */
function parts(type: string, ice: boolean) {
  const seg = ice ? 9 : 36, ss = ice ? 8 : 24, P: { geo: THREE.BufferGeometry; pos: number[]; rot?: number[]; head?: boolean }[] = [];
  const add = (geo: THREE.BufferGeometry, x = 0, y = 0, z = 0, extra: { rot?: number[]; head?: boolean } = {}) => P.push({ geo, pos: [x, y, z], ...extra });
  const sph = (r, sy = 1) => { const g = new THREE.SphereGeometry(r, ss, ss); g.scale(1, sy, 1); return g; };
  switch (type) {
    case 'p':
      add(lathe([...BASE, [0.2, 0.22], [0.14, 0.4], [0.15, 0.5], [0, 0.52]], seg)); break;
    case 'r': {
      add(lathe([...BASE, [0.21, 0.3], [0.2, 0.62], [0.27, 0.7], [0.31, 0.74], [0.31, 0.9], [0, 0.9]], seg));
      for (let i = 0; i < 6; i++) { const a = (i / 6) * Math.PI * 2; add(new THREE.BoxGeometry(0.15, 0.17, 0.11), Math.cos(a) * 0.24, 0.98, Math.sin(a) * 0.24, { rot: [0, -a, 0] }); }
      break;
    }
    case 'n':
      add(lathe([...BASE, [0.26, 0.12], [0, 0.12]], seg)); add(knightHead(), 0, 0.02, 0, { head: true }); break;
    case 'b':
      add(lathe([...BASE, [0.22, 0.25], [0.26, 0.42], [0.24, 0.58], [0.18, 0.68], [0, 0.7]], seg)); break;
    case 'q':
      add(lathe([...BASE, [0.2, 0.3], [0.15, 0.43], [0.12, 0.5], [0, 0.52]], seg)); break;
    case 'k':
      add(lathe([...BASE, [0.2, 0.3], [0.15, 0.43], [0.12, 0.5], [0, 0.52]], seg)); break;
  }
  return P;
}

const geoCache = new Map();
function geometry(type, ice) {
  const k = type + ice;
  if (!geoCache.has(k)) geoCache.set(k, parts(type, ice));
  return geoCache.get(k);
}

let base: { ice: THREE.MeshPhysicalMaterial; magma: THREE.MeshStandardMaterial } | null = null;
function baseMaterials() {
  if (base) return base;
  const mt = makeMarbleTextures();
  base = {
    ice: new THREE.MeshPhysicalMaterial({ color: 0xa8dcff, roughness: 0.12, metalness: 0.05, clearcoat: 1, clearcoatRoughness: 0.1, ior: 1.31, thickness: 0.7, flatShading: true, emissive: 0x1d6aa0, emissiveIntensity: 0.25, envMapIntensity: 1.4 }),
    magma: new THREE.MeshStandardMaterial({ color: 0x9a8f8a, map: mt.map, roughness: 0.32, metalness: 0.3, emissive: 0xff5a16, emissiveMap: mt.emissive, emissiveIntensity: 1, envMapIntensity: 0.9 }),
  };
  return base;
}

export const PIECE_HEIGHT = { p: 1.25, r: 1.35, n: 1.35, b: 1.65, q: 1.85, k: 2.0 };

/** A piece = group (placed by tweens) > inner (lift / glow) > meshes. */
export function createPiece(type, color, quality = 'high') {
  const ice = color === 'w', group = new THREE.Group(), inner = new THREE.Group();
  const mat: any = baseMaterials()[ice ? 'ice' : 'magma'].clone();
  if (ice && quality === 'high') { mat.transmission = 0.5; }
  group.add(inner);
  let head: THREE.Mesh | null = null;
  for (const p of geometry(type, ice)) {
    const m = new THREE.Mesh(p.geo, mat);
    m.position.set(p.pos[0]!, p.pos[1]!, p.pos[2]!); if (p.rot) m.rotation.set(p.rot[0]!, p.rot[1]!, p.rot[2]!);
    m.castShadow = true; m.receiveShadow = true;
    inner.add(m);
    if (p.head) head = m;
  }
  // High-fantasy character sculpting: each chess role gets a readable silhouette,
  // layered armor, face, regalia and elemental materials instead of a generic token.
  const trim = new THREE.MeshPhysicalMaterial({
    color: ice ? 0xe4f7ff : 0xffc08b, metalness: 0.86, roughness: 0.17,
    clearcoat: 1, emissive: ice ? 0x164a70 : 0x6b2108, emissiveIntensity: 0.24,
  });
  const gold = new THREE.MeshPhysicalMaterial({
    color: ice ? 0x9beaff : 0xffa24a, metalness: 0.9, roughness: 0.2,
    clearcoat: 1, emissive: ice ? 0x174e70 : 0x762006, emissiveIntensity: 0.3,
  });
  const gem = new THREE.MeshPhysicalMaterial({
    color: ice ? 0x8df0ff : 0xff4d1e, metalness: 0.18, roughness: 0.09,
    clearcoat: 1, emissive: ice ? 0x25cfff : 0xff3b08, emissiveIntensity: 1.25,
  });
  const dark = new THREE.MeshStandardMaterial({ color: ice ? 0x244d72 : 0x542016, metalness: 0.48, roughness: 0.34 });
  const skin = new THREE.MeshStandardMaterial({ color: ice ? 0xa9d9e8 : 0xb76b43, roughness: 0.58, metalness: 0.04 });
  const ownedGeometries:THREE.BufferGeometry[]=[];
  const ownedMaterials:THREE.Material[]=[trim,gold,gem,dark,skin];
  const ornament = (geo: THREE.BufferGeometry, material: THREE.Material, x: number, y: number, z: number, rot: number[] = [0,0,0]) => {
    ownedGeometries.push(geo);
    const mesh = new THREE.Mesh(geo, material);
    mesh.position.set(x, y, z); mesh.rotation.set(rot[0], rot[1], rot[2]);
    mesh.castShadow = true; mesh.receiveShadow = true; inner.add(mesh);
    return mesh;
  };
  const sphere = (x:number,y:number,z:number,sx:number,sy:number,sz:number,material:THREE.Material) => {
    const g = new THREE.SphereGeometry(1, 24, 18); g.scale(sx,sy,sz); return ornament(g,material,x,y,z);
  };
  const ring = (y: number, radius: number, tube = 0.025, material:THREE.Material = trim) =>
    ornament(new THREE.TorusGeometry(radius, tube, 10, 48), material, 0, y, 0, [Math.PI/2,0,0]);
  const limb = (a:THREE.Vector3,b:THREE.Vector3,r:number,material:THREE.Material) => {
    const d=new THREE.Vector3().subVectors(b,a), mesh=ornament(new THREE.CylinderGeometry(r*0.82,r,d.length(),16),material,0,0,0);
    mesh.position.copy(a).add(b).multiplyScalar(0.5); mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),d.normalize()); return mesh;
  };
  ring(0.16, 0.30, 0.025); ring(0.27, 0.205, 0.018, gold);
  let trunk:THREE.Mesh|null=null; const oars:THREE.Mesh[]=[];
  if (type === 'q' || type === 'k') {
    // Regal humanoid bust: cinched waist, armored torso, shoulders, arms and a real face.
    const isQueen=type==='q';
    const torsoGeo=lathe(isQueen?[[0,0],[0.105,0],[0.13,0.12],[0.105,0.23],[0.16,0.36],[0.19,0.43],[0.14,0.48],[0,0.48]]:[[0,0],[0.13,0],[0.16,0.14],[0.22,0.3],[0.25,0.43],[0.2,0.5],[0,0.5]],28);
    ornament(torsoGeo,trim,0,0.78,0);
    if(isQueen){
      // Sculpted gown/corset and jewel-setting across the bodice.
      const skirt=lathe([[0.12,0],[0.2,0.03],[0.28,0.18],[0.31,0.38],[0.24,0.47],[0.15,0.49],[0,0.49]],32);
      ornament(skirt,mat,0,0.53,0);
      sphere(0,1.15,0.02,0.19,0.105,0.14,trim);
      sphere(0,1.01,0.135,0.055,0.075,0.035,gem);
      // Flowing shoulder mantle and long hair locks.
      const capeShape=new THREE.Shape(); capeShape.moveTo(-0.16,1.19); capeShape.quadraticCurveTo(-0.34,0.92,-0.29,0.46); capeShape.quadraticCurveTo(0,0.32,0.29,0.46); capeShape.quadraticCurveTo(0.34,0.92,0.16,1.19); capeShape.closePath();
      const cape=ornament(new THREE.ShapeGeometry(capeShape),dark,0,0,-0.16,[0,0,0]); cape.material.side=THREE.DoubleSide;
      sphere(0,1.42,0,0.14,0.16,0.13,skin);
      sphere(-0.052,1.45,0.118,0.018,0.014,0.012,dark); sphere(0.052,1.45,0.118,0.018,0.014,0.012,dark);
      sphere(0,1.41,0.133,0.018,0.026,0.018,gold);
      sphere(0,1.49,-0.015,0.17,0.15,0.145,dark);
      for(const side of [-1,1]){
        const lock=limb(new THREE.Vector3(side*0.12,1.48,-0.015),new THREE.Vector3(side*0.19,1.05,0.02),0.035,gold);
        sphere(side*0.19,1.04,0.02,0.04,0.09,0.04,dark);
      }
      ring(1.56,0.15,0.024,gold);
      for(let i=0;i<7;i++){const a=-Math.PI*0.85+i*Math.PI*0.28; ornament(new THREE.ConeGeometry(0.035,0.17,8),gold,Math.cos(a)*0.145,1.62,Math.sin(a)*0.12,[0,0,-Math.cos(a)*0.18]);}
      sphere(0,1.75,0,0.055,0.08,0.055,gem);
      // Delicate pauldrons and articulated arms.
      for(const side of [-1,1]){
        sphere(side*0.22,1.16,0,0.105,0.09,0.12,gold);
        limb(new THREE.Vector3(side*0.23,1.13,0),new THREE.Vector3(side*0.29,0.91,0.08),0.045,trim);
        sphere(side*0.29,0.9,0.08,0.052,0.055,0.05,skin);
      }
    } else {
      // Broad king's cuirass, fur mantle, beard, cross crown and ceremonial sword pommel.
      sphere(0,1.2,-0.01,0.27,0.13,0.16,dark);
      sphere(0,1.48,0.01,0.16,0.17,0.14,skin);
      sphere(-0.06,1.5,0.135,0.022,0.018,0.012,dark); sphere(0.06,1.5,0.135,0.022,0.018,0.012,dark);
      sphere(0,1.44,0.145,0.022,0.03,0.018,gold);
      sphere(0,1.36,0.12,0.13,0.16,0.06,dark);
      for(let i=0;i<5;i++) sphere((i-2)*0.047,1.29,0.13,0.032,0.1,0.035,gold);
      for(const side of [-1,1]){
        sphere(side*0.25,1.18,0,0.13,0.11,0.15,gold);
        limb(new THREE.Vector3(side*0.24,1.16,0),new THREE.Vector3(side*0.3,0.9,0.09),0.06,trim);
        sphere(side*0.3,0.9,0.09,0.06,0.06,0.06,skin);
      }
      ring(1.62,0.16,0.03,gold);
      ornament(new THREE.BoxGeometry(0.09,0.3,0.09),gold,0,1.77,0);
      ornament(new THREE.BoxGeometry(0.3,0.08,0.09),gold,0,1.78,0);
      sphere(0,1.91,0,0.055,0.07,0.055,gem);
    }
    ring(0.78,isQueen?0.18:0.23,0.025,gold);
    sphere(0,1.08,0.145,0.035,0.035,0.025,gem);
  } else if (type === 'p') {
    // Little frost/ember sentinel with helmet, visor, shield and spear.
    sphere(0,0.72,0,0.13,0.18,0.12,trim);
    sphere(0,0.94,0.01,0.12,0.12,0.11,skin);
    sphere(0,1.02,0,0.145,0.12,0.13,gold);
    ornament(new THREE.BoxGeometry(0.18,0.045,0.025),dark,0,0.94,0.105);
    sphere(-0.22,0.77,0.04,0.12,0.17,0.045,gold);
    ornament(new THREE.ConeGeometry(0.035,0.5,10),trim,0.24,0.96,-0.015,[0,0,-0.1]);
    ring(0.62,0.16,0.022,gold);
    sphere(0,1.12,0,0.045,0.07,0.045,gem);
  } else if (type === 'r') {
    // A royal icebreaker / magma war-barge with keel, gunwales, oars, mast and sail.
    ring(0.76, 0.27, 0.03, gold);
    const hull = new THREE.SphereGeometry(0.34, 28, 18); hull.scale(1.0,0.28,1.62);
    ornament(hull,trim,0,0.34,0);
    const deck=new THREE.BoxGeometry(0.48,0.045,0.78); ornament(deck,gold,0,0.43,0);
    for(const side of [-1,1]){
      ornament(new THREE.CylinderGeometry(0.018,0.018,0.82,10),gold,side*0.29,0.48,0,[Math.PI/2,0,0]);
      const oar=ornament(new THREE.CylinderGeometry(0.014,0.02,0.72,10),trim,side*0.36,0.42,0.08,[Math.PI/2,0,side*0.18]); oars.push(oar);
      ornament(new THREE.SphereGeometry(0.04,12,10),gem,side*0.65,0.42,0.08);
    }
    ornament(new THREE.CylinderGeometry(0.025,0.035,0.82,12),gold,0,0.91,0);
    const sail=new THREE.Shape(); sail.moveTo(0,0); sail.quadraticCurveTo(0.22,0.3,0.02,0.66); sail.lineTo(-0.02,0.66); sail.quadraticCurveTo(-0.17,0.32,0,0); sail.closePath();
    const sailMesh=ornament(new THREE.ShapeGeometry(sail),ice?gem:dark,0.08,0.68,0.01,[0,0,0]); sailMesh.material.side=THREE.DoubleSide;
    for(let i=0;i<4;i++) ornament(new THREE.BoxGeometry(0.07,0.11,0.07),gem,Math.cos(i*Math.PI/2)*0.22,0.98,Math.sin(i*Math.PI/2)*0.22);
  } else if (type === 'b') {
    // Bishop reimagined as a richly armored elephant guardian, with broad ears and curling trunk.
    sphere(0,0.91,0.02,0.24,0.29,0.22,mat);
    sphere(-0.23,0.98,0,0.18,0.22,0.075,trim); sphere(0.23,0.98,0,0.18,0.22,0.075,trim);
    sphere(0,1.17,0.16,0.16,0.18,0.13,mat);
    sphere(-0.085,1.18,0.275,0.025,0.025,0.018,gem); sphere(0.085,1.18,0.275,0.025,0.025,0.018,gem);
    const trunkCurve=new THREE.CatmullRomCurve3([new THREE.Vector3(0,1.12,0.28),new THREE.Vector3(0,0.98,0.36),new THREE.Vector3(0.02,0.8,0.37),new THREE.Vector3(0.1,0.77,0.3),new THREE.Vector3(0.12,0.86,0.25)]);
    trunk=ornament(new THREE.TubeGeometry(trunkCurve,28,0.065,14,false),mat,0,0,0);
    for(const side of [-1,1]) ornament(new THREE.ConeGeometry(0.045,0.22,12),gold,side*0.11,1.0,0.27,[0,0,side*-0.3]);
    ring(1.34,0.15,0.028,gold);
    ornament(new THREE.ConeGeometry(0.08,0.18,8),gem,0,1.5,0);
    sphere(0,0.74,-0.05,0.28,0.12,0.22,dark);
  } else if (type === 'n') {
    // Sharper horse barding, muzzle, eyes, ears and a swept mane for a true war-steed.
    sphere(0.12,0.66,0.12,0.18,0.16,0.16,trim);
    sphere(0.28,0.55,0.17,0.17,0.095,0.12,mat);
    sphere(0.35,0.58,0.27,0.035,0.035,0.025,gem);
    sphere(0.08,0.94,-0.015,0.09,0.15,0.085,gold);
    ornament(new THREE.ConeGeometry(0.055,0.19,8),trim,0.02,1.08,0,[0,0,-0.18]);
    ornament(new THREE.ConeGeometry(0.055,0.19,8),trim,0.16,1.08,0,[0,0,0.18]);
    for(let i=0;i<5;i++) ornament(new THREE.ConeGeometry(0.035,0.19,7),gold,-0.15+i*0.075,1.05,-0.06,[0,0,Math.PI]);
    sphere(0.26,0.82,0.23,0.035,0.035,0.025,gem);
    ring(0.16,0.30,0.025,gold);
  }
  // knights face the enemy: white looks toward -z (black side), black toward +z
  const facing = ice ? Math.PI / 2 : -Math.PI / 2;
  if (type === 'n') inner.children.forEach((m) => { if (m === head) m.rotation.y = facing; });
  if (type === 'b') inner.rotation.y = ice ? Math.PI : 0; // elephant trunks face the opposing army
  const obj: any = { group, inner, mat, type, color, el: ice ? 'ice' : 'magma', sq: -1, head, facing, trunk, oars, lift: 0, glow: 0 };
  group.userData.piece = obj;
  group.traverse((o) => { o.userData.piece = obj; });
  obj.dispose = () => { ownedGeometries.forEach((g) => g.dispose()); ownedMaterials.forEach((m) => m.dispose()); mat.dispose(); };
  obj.setGlow = (g) => { obj.glow = g; if (ice) mat.emissiveIntensity = 0.25 + g * 0.9; else mat.emissiveIntensity = 1 + g * 2.2; };
  obj.setQuality = (q) => { if (ice) { mat.transmission = q === 'high' ? 0.5 : 0; mat.needsUpdate = true; } };
  return obj;
}
