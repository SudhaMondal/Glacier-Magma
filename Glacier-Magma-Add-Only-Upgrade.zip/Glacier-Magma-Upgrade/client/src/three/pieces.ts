import * as THREE from 'three';
import { makeMarbleTextures } from './textures.js';

const V = (pts) => pts.map(([r, y]) => new THREE.Vector2(r, y));
const BASE = [[0, 0], [0.37, 0], [0.38, 0.05], [0.36, 0.1], [0.28, 0.15]];
const lathe = (pts, seg) => new THREE.LatheGeometry(V(pts), seg);

function knightHead() {
  const sh = new THREE.Shape();
  [[-0.24, 0.12], [-0.3, 0.6], [-0.24, 1.0], [-0.1, 1.24], [-0.02, 1.36], [0.06, 1.26], [0.34, 0.98], [0.46, 0.84], [0.43, 0.72], [0.27, 0.73], [0.14, 0.64], [0.22, 0.4], [0.3, 0.12]]
    .forEach(([x, y], i) => (i ? sh.lineTo(x, y) : sh.moveTo(x, y)));
  const g = new THREE.ExtrudeGeometry(sh, { depth: 0.26, bevelEnabled: true, bevelThickness: 0.07, bevelSize: 0.05, bevelSegments: 2 });
  g.translate(-0.04, 0, -0.13);
  return g;
}

/** Returns [{geo, pos:[x,y,z], rot:[x,y,z]?, isHead?}] describing a piece; ice = faceted (low segment) lathes. */
function parts(type: string, ice: boolean) {
  const seg = ice ? 9 : 36, ss = ice ? 8 : 24, P: { geo: THREE.BufferGeometry; pos: number[]; rot?: number[]; head?: boolean }[] = [];
  const add = (geo: THREE.BufferGeometry, x = 0, y = 0, z = 0, extra: { rot?: number[]; head?: boolean } = {}) => P.push({ geo, pos: [x, y, z], ...extra });
  const sph = (r, sy = 1) => { const g = new THREE.SphereGeometry(r, ss, ss); g.scale(1, sy, 1); return g; };
  switch (type) {
    case 'p':
      add(lathe([...BASE, [0.2, 0.22], [0.14, 0.4], [0.15, 0.52], [0.23, 0.56], [0.23, 0.62], [0.14, 0.66], [0, 0.66]], seg)); add(sph(0.2), 0, 0.82); break;
    case 'r': {
      add(lathe([...BASE, [0.21, 0.3], [0.2, 0.62], [0.27, 0.7], [0.31, 0.74], [0.31, 0.9], [0, 0.9]], seg));
      for (let i = 0; i < 6; i++) { const a = (i / 6) * Math.PI * 2; add(new THREE.BoxGeometry(0.15, 0.17, 0.11), Math.cos(a) * 0.24, 0.98, Math.sin(a) * 0.24, { rot: [0, -a, 0] }); }
      break;
    }
    case 'n':
      add(lathe([...BASE, [0.26, 0.12], [0, 0.12]], seg)); add(knightHead(), 0, 0.02, 0, { head: true }); break;
    case 'b':
      add(lathe([...BASE, [0.19, 0.26], [0.12, 0.56], [0.2, 0.66], [0.22, 0.72], [0.12, 0.8], [0, 0.8]], seg)); add(sph(0.21, 1.4), 0, 1.02); add(sph(0.06), 0, 1.36); break;
    case 'q': {
      add(lathe([...BASE, [0.2, 0.3], [0.14, 0.7], [0.2, 0.95], [0.3, 1.12], [0.27, 1.2], [0, 1.2]], seg));
      for (let i = 0; i < 8; i++) { const a = (i / 8) * Math.PI * 2; add(new THREE.ConeGeometry(0.06, 0.24, 5), Math.cos(a) * 0.22, 1.32, Math.sin(a) * 0.22, { rot: [Math.sin(a) * 0.25, 0, -Math.cos(a) * 0.25] }); }
      add(sph(0.1), 0, 1.5); break;
    }
    case 'k':
      add(lathe([...BASE, [0.2, 0.3], [0.15, 0.8], [0.22, 1.05], [0.3, 1.2], [0.3, 1.3], [0, 1.3]], seg));
      add(new THREE.BoxGeometry(0.11, 0.44, 0.11), 0, 1.58); add(new THREE.BoxGeometry(0.32, 0.11, 0.11), 0, 1.64); break;
  }
  return P;
}

const geoCache = new Map();
function geometry(type, ice) {
  const k = type + ice;
  if (!geoCache.has(k)) geoCache.set(k, parts(type, ice));
  return geoCache.get(k);
}

let base: { ice: THREE.MeshPhysicalMaterial; magma: THREE.MeshStandardMaterial } | null = null;
function baseMaterials() {
  if (base) return base;
  const mt = makeMarbleTextures();
  base = {
    ice: new THREE.MeshPhysicalMaterial({ color: 0xa8dcff, roughness: 0.12, metalness: 0.05, clearcoat: 1, clearcoatRoughness: 0.1, ior: 1.31, thickness: 0.7, flatShading: true, emissive: 0x1d6aa0, emissiveIntensity: 0.25, envMapIntensity: 1.4 }),
    magma: new THREE.MeshStandardMaterial({ color: 0x9a8f8a, map: mt.map, roughness: 0.32, metalness: 0.3, emissive: 0xff5a16, emissiveMap: mt.emissive, emissiveIntensity: 1, envMapIntensity: 0.9 }),
  };
  return base;
}

export const PIECE_HEIGHT = { p: 1.0, r: 1.1, n: 1.25, b: 1.4, q: 1.65, k: 1.85 };

/** A piece = group (placed by tweens) > inner (lift / glow) > meshes. */
export function createPiece(type, color, quality = 'high') {
  const ice = color === 'w', group = new THREE.Group(), inner = new THREE.Group();
  const mat: any = baseMaterials()[ice ? 'ice' : 'magma'].clone();
  if (ice && quality === 'high') { mat.transmission = 0.5; }
  group.add(inner);
  let head: THREE.Mesh | null = null;
  for (const p of geometry(type, ice)) {
    const m = new THREE.Mesh(p.geo, mat);
    m.position.set(p.pos[0]!, p.pos[1]!, p.pos[2]!); if (p.rot) m.rotation.set(p.rot[0]!, p.rot[1]!, p.rot[2]!);
    m.castShadow = true; m.receiveShadow = true;
    inner.add(m);
    if (p.head) head = m;
  }
  // Sculptural detailing: polished trim, inset gems and distinct regalia turn
  // the silhouettes into collectible fantasy figurines rather than plain tokens.
  const trim = new THREE.MeshPhysicalMaterial({
    color: ice ? 0xd8f4ff : 0xffa35c, metalness: 0.82, roughness: 0.2,
    clearcoat: 1, emissive: ice ? 0x164a70 : 0x6b2108, emissiveIntensity: 0.28,
  });
  const gem = new THREE.MeshPhysicalMaterial({
    color: ice ? 0x79e6ff : 0xff5a21, metalness: 0.22, roughness: 0.12,
    clearcoat: 1, emissive: ice ? 0x2bcbff : 0xff3b08, emissiveIntensity: 1.1,
  });
  const ornament = (geo: THREE.BufferGeometry, material: THREE.Material, x: number, y: number, z: number, rx = 0) => {
    const mesh = new THREE.Mesh(geo, material);
    mesh.position.set(x, y, z); mesh.rotation.x = rx;
    mesh.castShadow = true; mesh.receiveShadow = true; inner.add(mesh);
    return mesh;
  };
  const ring = (y: number, radius: number, tube = 0.025) =>
    ornament(new THREE.TorusGeometry(radius, tube, 8, 36), trim, 0, y, 0, Math.PI / 2);
  ring(0.16, 0.30, 0.025);
  ring(0.27, 0.205, 0.018);
  if (type === 'k' || type === 'q') {
    const crownY = type === 'k' ? 1.31 : 1.22;
    ring(crownY, type === 'k' ? 0.28 : 0.25, 0.035);
    for (let i = 0; i < 8; i++) {
      const a = i * Math.PI / 4, r = type === 'k' ? 0.235 : 0.205;
      ornament(new THREE.ConeGeometry(0.045, type === 'k' ? 0.25 : 0.19, 6),
        trim, Math.cos(a) * r, crownY + 0.11, Math.sin(a) * r,
        0);
    }
    ornament(new THREE.OctahedronGeometry(0.105, 0), gem, 0, crownY + 0.24, 0);
  } else if (type === 'p') {
    ring(0.62, 0.16, 0.022);
    ornament(new THREE.OctahedronGeometry(0.07, 0), gem, 0, 0.91, 0);
  } else if (type === 'r') {
    ring(0.76, 0.27, 0.03);
    // The rook is an elemental river-barge fortress: a sculpted hull and side oars
    // sit beneath its familiar tower silhouette, so its rowing cue has a visual match.
    const hull = new THREE.SphereGeometry(0.31, 20, 14);
    hull.scale(1.0, 0.30, 1.55);
    ornament(hull, trim, 0, 0.36, 0);
    for (const side of [-1, 1]) {
      const oar = new THREE.CylinderGeometry(0.012, 0.018, 0.62, 8);
      ornament(oar, trim, side * 0.34, 0.42, 0.08, Math.PI / 2);
      ornament(new THREE.SphereGeometry(0.035, 10, 8), gem, side * 0.58, 0.42, 0.08);
    }
    for (let i = 0; i < 4; i++) {
      const a = i * Math.PI / 2;
      ornament(new THREE.BoxGeometry(0.07, 0.11, 0.07), gem, Math.cos(a) * 0.22, 0.98, Math.sin(a) * 0.22);
    }
  } else if (type === 'b') {
    // The bishop is styled as an elephant guardian with tusks and a curled trunk.
    ornament(new THREE.SphereGeometry(0.09, 16, 12), trim, -0.16, 1.00, 0.02);
    ornament(new THREE.SphereGeometry(0.09, 16, 12), trim, 0.16, 1.00, 0.02);
    const trunkCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0, 1.05, 0.13), new THREE.Vector3(0, 0.91, 0.23),
      new THREE.Vector3(0.025, 0.76, 0.25), new THREE.Vector3(0.09, 0.72, 0.18),
    ]);
    ornament(new THREE.TubeGeometry(trunkCurve, 18, 0.055, 10, false), mat, 0, 0, 0);
    ornament(new THREE.ConeGeometry(0.035, 0.17, 10), trim, -0.12, 0.91, 0.13, -0.5);
    ornament(new THREE.ConeGeometry(0.035, 0.17, 10), trim, 0.12, 0.91, 0.13, -0.5);
    ornament(new THREE.OctahedronGeometry(0.07, 0), gem, 0, 1.39, 0);
  } else if (type === 'n') {
    ornament(new THREE.SphereGeometry(0.045, 12, 10), gem, -0.12, 0.76, 0.13);
    ornament(new THREE.SphereGeometry(0.045, 12, 10), gem, 0.12, 0.76, 0.13);
  }
  // knights face the enemy: white looks toward -z (black side), black toward +z
  const facing = ice ? Math.PI / 2 : -Math.PI / 2;
  if (type === 'n') inner.children.forEach((m) => { if (m === head) m.rotation.y = facing; });
  if (type === 'b') inner.rotation.y = ice ? Math.PI : 0; // elephant trunks face the opposing army
  const obj: any = { group, inner, mat, type, color, el: ice ? 'ice' : 'magma', sq: -1, head, facing, lift: 0, glow: 0 };
  group.userData.piece = obj;
  group.traverse((o) => { o.userData.piece = obj; });
  obj.setGlow = (g) => { obj.glow = g; if (ice) mat.emissiveIntensity = 0.25 + g * 0.9; else mat.emissiveIntensity = 1 + g * 2.2; };
  obj.setQuality = (q) => { if (ice) { mat.transmission = q === 'high' ? 0.5 : 0; mat.needsUpdate = true; } };
  return obj;
}
